import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth, db, ensureAnonAuth } from './firebase';
import { doc, getDoc, setDoc, serverTimestamp, onSnapshot } from 'firebase/firestore';
import { getStudentById, Student } from './students';
import { handleFirestoreError, OperationType } from './firestore-error';

interface SessionContextType {
  studentId: string | null;
  isAdmin: boolean;
  student: Student | null;
  login: (id: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const SessionContext = createContext<SessionContextType | null>(null);

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [studentId, setStudentId] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [student, setStudent] = useState<Student | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Attempt local auto-login based on localStorage + firebase auth state
    const initAuth = async () => {
      await ensureAnonAuth();
      const user = auth.currentUser;
      if (user) {
        try {
          const docRef = doc(db, 'identities', user.uid);
          const snap = await getDoc(docRef).catch(e => {
            handleFirestoreError(e, OperationType.GET, 'identities');
            return null; // Will reach it, but handle wrapper throws
          });
          if (snap?.exists()) {
            const data = snap.data();
            const sid = data.studentId;
            if (sid === '30102554') {
              setIsAdmin(true);
              setStudentId(sid);
            } else {
              const stud = getStudentById(sid);
              if (stud) {
                setStudentId(sid);
                setStudent(stud);
              }
            }
          }
        } catch (error) {
          console.error(error);
        }
      }
      setIsLoading(false);
    };

    const unsub = auth.onAuthStateChanged((user) => {
      if (user) {
        initAuth();
      } else {
        setIsLoading(false);
      }
    });

    return () => unsub();
  }, []);

  const login = async (id: string) => {
    if (id !== '30102554' && !getStudentById(id)) return false;
    
    await ensureAnonAuth();
    if (!auth.currentUser) return false;

    // Save identity
    try {
      await setDoc(doc(db, 'identities', auth.currentUser.uid), {
        studentId: id,
        createdAt: serverTimestamp()
      });
      // Set local
      if (id === '30102554') {
        setIsAdmin(true);
        setStudentId(id);
      } else {
        setStudentId(id);
        setStudent(getStudentById(id) || null);
      }
      return true;
    } catch (e: any) {
      if (e?.code === 'permission-denied') {
        // Already exists? Let's check what it has.
        const docRef = doc(db, 'identities', auth.currentUser.uid);
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          const data = snap.data();
          if (data.studentId === id) {
             // already matching
            if (id === '30102554') {
              setIsAdmin(true);
              setStudentId(id);
            } else {
              setStudentId(id);
              setStudent(getStudentById(id) || null);
            }
            return true;
          }
        }
      }
      console.error(e);
      return false;
    }
  };

  const logout = () => {
    setStudentId(null);
    setStudent(null);
    setIsAdmin(false);
    auth.signOut();
  };

  return (
    <SessionContext.Provider value={{ studentId, isAdmin, student, login, logout, isLoading }}>
      {children}
    </SessionContext.Provider>
  );
}

export function useSession() {
  const context = useContext(SessionContext);
  if (!context) throw new Error('useSession must be used within SessionProvider');
  return context;
}
