export interface Student {
  number: number;
  id: string;
  fullName: string;
  firstName: string;
}

export const students: Student[] = [
  { number: 1, id: '52429', fullName: 'เด็กชายกนกธร ทองเผือก', firstName: 'กนกธร' },
  { number: 2, id: '52430', fullName: 'เด็กชายกันต์ธีร์ อัครวิวัฒน์ดำรง', firstName: 'กันต์ธีร์' },
  { number: 3, id: '52431', fullName: 'เด็กชายชาญณรงค์ ปรีเอี่ยม', firstName: 'ชาญณรงค์' },
  { number: 4, id: '52432', fullName: 'เด็กชายชินดนัย วงศ์เปี้ย', firstName: 'ชินดนัย' },
  { number: 5, id: '52433', fullName: 'เด็กชายณัฏฐธนัท นุชชม', firstName: 'ณัฏฐธนัท' },
  { number: 6, id: '52434', fullName: 'เด็กชายณัฏฐกรณ์ ธนะสมบัติ', firstName: 'ณัฏฐกรณ์' },
  { number: 7, id: '52435', fullName: 'เด็กชายธนกฤช อรัญเวทย์', firstName: 'ธนกฤช' },
  { number: 8, id: '52436', fullName: 'เด็กชายธนพล ฤทธิ์ศิริ', firstName: 'ธนพล' },
  { number: 9, id: '52437', fullName: 'เด็กชายภัสกรณ์ เสือเจริญ', firstName: 'ภัสกรณ์' },
  { number: 10, id: '52438', fullName: 'เด็กชายปฏิภาณ ธนัตถ์นันทิพัฒน์', firstName: 'ปฏิภาณ' },
  { number: 11, id: '52439', fullName: 'เด็กชายปวณ์รัฐ สุวรรณเพ็ชร์', firstName: 'ปวณ์รัฐ' },
  { number: 12, id: '52440', fullName: 'เด็กชายปัณณวิชญ์ เอกศิริ', firstName: 'ปัณณวิชญ์' },
  { number: 13, id: '52441', fullName: 'เด็กชายพุฒิเศรษฐ์ เบญจโอฬาร', firstName: 'พุฒิเศรษฐ์' },
  { number: 14, id: '52442', fullName: 'เด็กชายภูมิศรัณย์ บวรพัฒนวัฒน์', firstName: 'ภูมิศรัณย์' },
  { number: 15, id: '52443', fullName: 'เด็กชายมกรา ยาหมิน', firstName: 'มกรา' },
  { number: 16, id: '52444', fullName: 'เด็กชายเมธานันท์ อภิยากรณ์', firstName: 'เมธานันท์' },
  { number: 17, id: '52445', fullName: 'เด็กชายหฤษฎ์ วัชรนุกูลเกียรติ', firstName: 'หฤษฎ์' },
  { number: 18, id: '52446', fullName: 'เด็กหญิงกรกณัฐ เอี่ยมศรีรักษ์', firstName: 'กรกณัฐ' },
  { number: 19, id: '52447', fullName: 'เด็กหญิงเกวลิน จันทร์เวียง', firstName: 'เกวลิน' },
  { number: 20, id: '52448', fullName: 'เด็กหญิงจิราภัสส์ อัศวกุลศร', firstName: 'จิราภัสส์' },
  { number: 21, id: '52449', fullName: 'เด็กหญิงฐิติยารัตน์ เรียงทองหลาง', firstName: 'ฐิติยารัตน์' },
  { number: 22, id: '52450', fullName: 'เด็กหญิงณัฐวิภรณ์ อังเดชาวัฒน์', firstName: 'ณัฐวิภรณ์' },
  { number: 23, id: '52451', fullName: 'เด็กหญิงปพิชญา คติยรังสรรค์', firstName: 'ปพิชญา' },
  { number: 24, id: '52452', fullName: 'เด็กหญิงปภาดา วิริยจารี', firstName: 'ปภาดา' },
  { number: 25, id: '52453', fullName: 'เด็กหญิงปภาดา ปุณยสิริภัทร', firstName: 'ปภาดา' },
  { number: 26, id: '52454', fullName: 'เด็กหญิงเปมิกา สีรัง', firstName: 'เปมิกา' },
  { number: 27, id: '52455', fullName: 'เด็กหญิงพิมพ์ชนก จูทา', firstName: 'พิมพ์ชนก' },
  { number: 28, id: '52456', fullName: 'เด็กหญิงพิมพ์พิสาข์ อ้วนไตร', firstName: 'พิมพ์พิสาข์' },
  { number: 29, id: '52457', fullName: 'เด็กหญิงพิมพ์วิภา วิเชียรรัตน์', firstName: 'พิมพ์วิภา' },
  { number: 30, id: '52458', fullName: 'เด็กหญิงเพียงลดา เดชตุลา', firstName: 'เพียงลดา' },
  { number: 31, id: '52459', fullName: 'เด็กหญิงภัสรดา ฤทธิ์เทพ', firstName: 'ภัสรดา' },
  { number: 32, id: '52460', fullName: 'เด็กหญิงภัสรดา จันทร์หอม', firstName: 'ภัสรดา' },
  { number: 33, id: '52461', fullName: 'เด็กหญิงสุพิชญ์นันท์ ศิริ', firstName: 'สุพิชญ์นันท์' },
  { number: 34, id: '52462', fullName: 'เด็กหญิงอรนิชชา พิลาวัลย์', firstName: 'อรนิชชา' },
  { number: 35, id: '52463', fullName: 'เด็กหญิงอรัญรดา รุ่งสง่า', firstName: 'อรัญรดา' },
  { number: 36, id: '52464', fullName: 'เด็กหญิงอัญญภัสสร ไพจิตโรจนา', firstName: 'อัญญภัสสร' }
];

export function getStudentById(id: string): Student | undefined {
  return students.find(s => s.id === id);
}
