import React, { useState } from 'react';
import { useSession } from '../lib/SessionContext';
import { KeyRound, ShieldAlert } from 'lucide-react';

export function Login() {
  const [id, setId] = useState('');
  const { login } = useSession();
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id) return;
    setLoading(true);
    setError(false);
    const success = await login(id);
    if (!success) {
      setError(true);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-8 relative overflow-hidden">
        {/* Decorative flair */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 via-emerald-400 to-emerald-500" />
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/20">
            <KeyRound className="w-8 h-8 text-emerald-400" />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Room 924</h1>
          <p className="text-slate-400 mt-2 text-sm">Classroom Hub • M.3/4</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="studentId" className="block text-sm font-medium text-slate-300 mb-2">
              รหัสประจำตัว (5 หลัก)
            </label>
            <div className="relative">
              <input
                id="studentId"
                type="text"
                pattern="[0-9]*"
                maxLength={8}
                value={id}
                onChange={(e) => setId(e.target.value.replace(/\D/, ''))}
                className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-colors duration-200"
                placeholder=""
              />
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-amber-500/90 text-sm bg-amber-500/10 p-3 rounded-lg border border-amber-500/20">
              <ShieldAlert className="w-4 h-4" />
              <span>รหัสไม่ถูกต้อง หรือมีข้อผิดพลาด</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || id.length < 5}
            className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-xl shadow-lg shadow-emerald-500/20 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 focus:ring-offset-slate-900 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98]"
          >
            {loading ? 'Processing...' : 'เข้าสู่ระบบ'}
          </button>
        </form>
      </div>
    </div>
  );
}
