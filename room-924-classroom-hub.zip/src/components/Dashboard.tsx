import React, { useEffect, useState } from 'react';
import { useSession } from '../lib/SessionContext';
import { db, auth } from '../lib/firebase';
import { collection, onSnapshot, doc, setDoc, deleteDoc, serverTimestamp, query, orderBy } from 'firebase/firestore';
import { getStudentById } from '../lib/students';
import { handleFirestoreError, OperationType } from '../lib/firestore-error';
import { Users, User, Megaphone, LogOut, Tv, BookUser } from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: (string | undefined | null | false)[]) {
  return twMerge(clsx(inputs));
}

export function Dashboard() {
  const { student, isAdmin, logout } = useSession();
  const [activeTab, setActiveTab] = useState<'seating' | 'voting' | 'news'>('seating');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-300">
      {/* Navbar */}
      <header className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center border border-emerald-500/30">
              <BookUser className="w-5 h-5 text-emerald-400" />
            </div>
            <h1 className="font-semibold text-white tracking-wide">Room 924</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium text-emerald-400 bg-emerald-400/10 px-3 py-1.5 rounded-full border border-emerald-400/20">
              {isAdmin ? 'Admin' : student?.firstName}
            </span>
            <button 
              onClick={logout}
              className="text-slate-400 hover:text-white transition-colors p-2 hover:bg-slate-800 rounded-lg"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 relative">
        <Tabs active={activeTab} onChange={setActiveTab} />
        
        <div className="mt-8">
          {activeTab === 'seating' && <SeatingChart />}
          {activeTab === 'voting' && <VotingSystem />}
          {activeTab === 'news' && <NewsBoard />}
        </div>
      </main>
    </div>
  );
}

function Tabs({ active, onChange }: { active: string, onChange: (t: any) => void }) {
  const tabs = [
    { id: 'seating', label: 'ผังที่นั่ง', icon: Users },
    { id: 'voting', label: 'โหวตหัวหน้า', icon: User },
    { id: 'news', label: 'ข่าวสาร', icon: Megaphone },
  ];

  return (
    <div className="flex gap-2 p-1 bg-slate-900 rounded-xl border border-slate-800 w-fit">
      {tabs.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={cn(
            "flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
            active === t.id 
              ? "bg-slate-800 text-white shadow-sm ring-1 ring-slate-700" 
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
          )}
        >
          <t.icon className="w-4 h-4" />
          {t.label}
        </button>
      ))}
    </div>
  );
}

function SeatingChart() {
  const { studentId, isAdmin } = useSession();
  const [seats, setSeats] = useState<Record<string, string>>({}); // seatId -> studentId

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'seats'), (snap) => {
      const data: Record<string, string> = {};
      snap.forEach(doc => {
        data[doc.id] = doc.data().studentId;
      });
      setSeats(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'seats');
    });
    return () => unsub();
  }, []);

  const handleSeatClick = async (seatNumberStr: string) => {
    if (!studentId || isAdmin) return; // Admins don't claim seats in this proto, or we can add that handling
    const currentOccupant = seats[seatNumberStr];

    if (currentOccupant === studentId) {
      // Leave seat
      try {
        await deleteDoc(doc(db, 'seats', seatNumberStr));
      } catch (e) {
        handleFirestoreError(e, OperationType.DELETE, `seats/${seatNumberStr}`);
      }
    } else if (!currentOccupant) {
      // Check if user already has a seat
      const existingSeatId = Object.keys(seats).find(k => seats[k] === studentId);
      if (existingSeatId) {
        try {
          await deleteDoc(doc(db, 'seats', existingSeatId));
        } catch (e) {
           console.error(e)
        }
      }
      try {
        await setDoc(doc(db, 'seats', seatNumberStr), {
          studentId,
          updatedAt: serverTimestamp()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.CREATE, `seats/${seatNumberStr}`);
      }
    }
  };

  const rows = [
    [1,2, 3,4, 5,6, 7,8],
    [9,10, 11,12, 13,14, 15,16],
    [17,18, 19,20, 21,22, 23,24],
    [25,26, 27,28, 29,30, null,null],
    [31,32, 33,34, 35,36, null,null]
  ];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 overflow-x-auto min-h-[600px]">
      <div className="min-w-[800px] flex flex-col items-center">
        {/* Board / TV */}
        <div className="w-full max-w-4xl bg-emerald-900/40 border-2 border-emerald-800/50 rounded-xl p-4 mb-4 flex items-center justify-center gap-3 shadow-[0_0_30px_-10px_rgba(16,185,129,0.2)]">
          <Tv className="text-emerald-500 w-6 h-6" />
          <span className="text-emerald-400 font-medium tracking-wide">กระดาน / TV</span>
        </div>

        {/* Teacher Desk */}
        <div className="w-full max-w-4xl flex justify-end mb-12 pr-8">
          <div className="bg-amber-900/30 border border-amber-600/50 rounded-lg px-6 py-3 flex items-center gap-2 shadow-[0_0_20px_-10px_rgba(245,158,11,0.2)]">
            <User className="text-amber-500 w-5 h-5" />
            <span className="text-amber-400 font-medium text-sm">โต๊ะครู</span>
          </div>
        </div>

        {/* Desks Grid */}
        <div className="flex flex-col gap-6 items-start w-full max-w-5xl pl-4">
          {rows.map((rowItems, rIdx) => (
            <div key={rIdx} className="flex gap-x-12 mx-auto">
              {/* Blocks of 2 */}
              <div className="flex gap-2 w-[152px]">
                {[rowItems[0], rowItems[1]].map((seatNum, i) => seatNum ? (
                  <Seat key={seatNum} seatNum={seatNum} occupant={seats[seatNum.toString()]} onClick={() => handleSeatClick(seatNum.toString())} />
                ) : <div key={`empty-1-${i}`} className="w-[72px] h-[84px]" />)}
              </div>
              <div className="flex gap-2 w-[152px]">
                {[rowItems[2], rowItems[3]].map((seatNum, i) => seatNum ? (
                  <Seat key={seatNum} seatNum={seatNum} occupant={seats[seatNum.toString()]} onClick={() => handleSeatClick(seatNum.toString())} />
                ) : <div key={`empty-2-${i}`} className="w-[72px] h-[84px]" />)}
              </div>
              <div className="flex gap-2 w-[152px]">
                {[rowItems[4], rowItems[5]].map((seatNum, i) => seatNum ? (
                  <Seat key={seatNum} seatNum={seatNum} occupant={seats[seatNum.toString()]} onClick={() => handleSeatClick(seatNum.toString())} />
                ) : <div key={`empty-3-${i}`} className="w-[72px] h-[84px]" />)}
              </div>
              <div className="flex gap-2 w-[152px]">
                {[rowItems[6], rowItems[7]].map((seatNum, i) => seatNum ? (
                  <Seat key={seatNum} seatNum={seatNum} occupant={seats[seatNum.toString()]} onClick={() => handleSeatClick(seatNum.toString())} />
                ) : <div key={`empty-4-${i}`} className="w-[72px] h-[84px]" />)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Seat({ seatNum, occupant, onClick }: { seatNum: number, occupant?: string, onClick: () => void }) {
  const { studentId } = useSession();
  const occupantInfo = occupant ? getStudentById(occupant) : null;
  const isMine = occupant === studentId;

  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-[72px] h-[84px] bg-slate-800/80 border border-slate-700/80 rounded-xl relative flex flex-col items-center pt-2 transition-all duration-200 group overflow-hidden",
        !occupant && "hover:border-emerald-500/50 hover:bg-slate-700/50 cursor-pointer",
        occupant && !isMine && "opacity-80 cursor-default",
        isMine && "border-emerald-500 bg-emerald-500/10 shadow-[0_0_15px_-3px_rgba(16,185,129,0.3)] hover:bg-red-500/10 hover:border-red-500 cursor-pointer"
      )}
    >
      <span className="text-xs font-mono text-slate-500 group-hover:text-slate-400 absolute top-2 left-2">{seatNum}</span>
      <div className="mt-4 flex flex-col items-center justify-center w-full">
        {occupantInfo ? (
          <>
            <span className={cn("text-[11px] font-medium truncate w-[90%] text-center mt-2", isMine ? "text-emerald-400" : "text-amber-200")}>
              {occupantInfo.firstName}
            </span>
            <span className="text-[9px] text-slate-500">{occupantInfo.number}</span>
          </>
        ) : (
           <div className="w-5 h-5 rounded-full border border-dashed border-slate-600 mt-2 opacity-50" />
        )}
      </div>
      {/* Decorative chair top */}
      <div className="absolute -top-[1px] w-[80%] h-1 bg-slate-700 rounded-b-md" />
    </button>
  );
}

function VotingSystem() {
  const { studentId, isAdmin } = useSession();
  const [votes, setVotes] = useState<Record<string, string>>({}); // sid -> decision
  const [myVote, setMyVote] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'votes'), (snap) => {
      const data: Record<string, string> = {};
      snap.forEach(doc => {
        data[doc.id] = doc.data().decision;
      });
      setVotes(data);
      if (studentId && data[studentId]) {
        setMyVote(data[studentId]);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'votes');
    });
    return () => unsub();
  }, [studentId]);

  const castVote = async (decision: 'keep' | 'change') => {
    if (!studentId || isAdmin) return;
    try {
      await setDoc(doc(db, 'votes', studentId), {
        decision,
        updatedAt: serverTimestamp()
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `votes/${studentId}`);
    }
  };

  const totalVotes = Object.keys(votes).length;
  const keepVotes = Object.values(votes).filter(v => v === 'keep').length;
  const changeVotes = Object.values(votes).filter(v => v === 'change').length;

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-amber-500" />
        <h2 className="text-2xl font-bold text-white mb-2">โหวตหัวหน้าห้อง</h2>
        <p className="text-slate-400 text-sm">การตัดสินใจ "เปลี่ยน" หรือ "ไม่เปลี่ยน" ประจำเทอม</p>
        
        {!isAdmin ? (
          <div className="mt-8 flex gap-4 justify-center">
            <button
              onClick={() => castVote('keep')}
              className={cn(
                "flex-1 max-w-[200px] py-4 rounded-xl border-2 font-medium transition-all",
                myVote === 'keep' 
                  ? "border-emerald-500 bg-emerald-500/10 text-emerald-400 shadow-[0_0_20px_-5px_rgba(16,185,129,0.3)]" 
                  : "border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700"
              )}
            >
              ไม่เปลี่ยน
            </button>
            <button
              onClick={() => castVote('change')}
              className={cn(
                "flex-1 max-w-[200px] py-4 rounded-xl border-2 font-medium transition-all",
                myVote === 'change' 
                  ? "border-amber-500 bg-amber-500/10 text-amber-400 shadow-[0_0_20px_-5px_rgba(245,158,11,0.3)]" 
                  : "border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700"
              )}
            >
              เปลี่ยน
            </button>
          </div>
        ) : (
           <div className="mt-6 p-4 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20 text-sm">
             ผู้ดูแลระบบไม่สามารถโหวตได้
           </div>
        )}
      </div>

      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <h3 className="text-sm font-semibold text-slate-400 mb-6 uppercase tracking-wider">Live Results ({totalVotes} votes)</h3>
        
        <div className="space-y-6">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-emerald-400 font-medium">ไม่เปลี่ยน (Keep)</span>
              <span className="text-white">{keepVotes} เสียง</span>
            </div>
            <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div 
                className="h-full bg-emerald-500 transition-all duration-500 ease-out"
                style={{ width: `${totalVotes ? (keepVotes / totalVotes) * 100 : 0}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-amber-400 font-medium">เปลี่ยน (Change)</span>
              <span className="text-white">{changeVotes} เสียง</span>
            </div>
            <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div 
                className="h-full bg-amber-500 transition-all duration-500 ease-out"
                style={{ width: `${totalVotes ? (changeVotes / totalVotes) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function NewsBoard() {
  const { isAdmin } = useSession();
  const [news, setNews] = useState<any[]>([]);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'announcements'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      setNews(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (error) => {
      console.error(error);
    });
    return () => unsub();
  }, []);

  const postNews = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || !title || !content) return;
    
    // Auto generate ID based on time
    const id = Date.now().toString();
    try {
      await setDoc(doc(db, 'announcements', id), {
        title,
        content,
        authorId: '30102554',
        createdAt: serverTimestamp()
      });
      setTitle('');
      setContent('');
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `announcements/${id}`);
    }
  };

  const deleteNews = async (id: string) => {
    if (!isAdmin) return;
    try {
      await deleteDoc(doc(db, 'announcements', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `announcements/${id}`);
    }
  };

  return (
    <div className="space-y-6">
      {isAdmin && (
        <form onSubmit={postNews} className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <h3 className="text-lg font-semibold text-white mb-4">ประกาศข่าวใหม่</h3>
          <div className="space-y-4">
            <input 
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="หัวข้อ"
              className="w-full px-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-emerald-500"
            />
            <textarea 
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="เนื้อหา..."
              rows={3}
              className="w-full px-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-emerald-500 resize-none"
            />
            <button type="submit" disabled={!title || !content} className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg disabled:opacity-50 transition-colors">
              โพสต์ประกาศ
            </button>
          </div>
        </form>
      )}

      <div className="space-y-4">
        {news.length === 0 ? (
          <div className="text-center py-12 text-slate-500 bg-slate-900 border border-dashed border-slate-800 rounded-2xl">
            ยังไม่มีประกาศใดๆ
          </div>
        ) : (
          news.map(item => (
            <div key={item.id} className="bg-slate-900 border border-slate-800 p-6 rounded-2xl relative overflow-hidden group">
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-emerald-500/50" />
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">{item.title}</h4>
                  <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">{item.content}</p>
                  <p className="text-xs text-slate-500 mt-4">
                    {item.createdAt ? new Date(item.createdAt.toDate()).toLocaleDateString('th-TH', { hour: '2-digit', minute: '2-digit' }) : 'Just now'}
                  </p>
                </div>
                {isAdmin && (
                  <button onClick={() => deleteNews(item.id)} className="text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity p-2">
                    ลบ
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
